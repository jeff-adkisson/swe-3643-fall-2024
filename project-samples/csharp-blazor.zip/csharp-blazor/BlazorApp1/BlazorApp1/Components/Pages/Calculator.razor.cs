using Microsoft.AspNetCore.Components;

namespace BlazorApp1.Components.Pages;

public partial class Calculator : ComponentBase
{
    private string Data { get; set; } = "";

    private string Message { get; set; } = "Enter values below, then select operation";

    private List<XY> Points { get; set; } = new();

    private void HandleDataChange(ChangeEventArgs obj)
    {
        Data = obj.Value?.ToString() ?? string.Empty;
        var pairs = Data.Split('\n');
        foreach (var pair in pairs)
        {
            var xy = pair.Split(',');
            if (xy.Length != 2) continue;

            if (!double.TryParse(xy[0], out var x) || !double.TryParse(xy[1], out var y)) continue;
            Points.Add(new XY(x, y));
        }

        Message = string.Join(", ", Points);
    }

    public sealed record XY(double X, double Y);
}