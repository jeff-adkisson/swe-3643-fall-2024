package org.example.webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.swe3643.calculatorengine.Calculator;
import org.swe3643.calculatorengine.CalculatorResult;


@SpringBootApplication
@RestController
public class WebApplication {

    public static void main(String[] args) {

        SpringApplication.run(WebApplication.class, args);
    }

    @GetMapping("/hello")
    public String sayHello(@RequestParam(value = "myName", defaultValue = "World") String name) {
        return String.format("Hello %s!", name);
    }

    @GetMapping("/add")
    public String add(@RequestParam(value = "inputA", defaultValue = "0") String inputA,
                      @RequestParam(value = "inputB", defaultValue = "0") String inputB) {

        double inputANum;
        double inputBNum;
        try  {

            inputANum = Double.parseDouble(inputA);
            inputBNum = Double.parseDouble(inputB);

            if (Double.isNaN(inputANum) || Double.isNaN(inputBNum)) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            return "<h1>Numeric Values Only: " + inputA + ", " + inputB + "</h1>";
        }

        CalculatorResult result = Calculator.add(inputANum, inputBNum);
        StringBuilder sb = new StringBuilder();
        sb.append("<h1>").append(result.getOperation()).append("<br/>").append(result.getResult()).append("</h1>");
        return sb.toString();
    }

}
