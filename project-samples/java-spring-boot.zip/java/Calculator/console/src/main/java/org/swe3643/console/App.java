package org.swe3643.console;

import org.swe3643.calculatorengine.Calculator;
import org.swe3643.calculatorengine.CalculatorResult;

public class App
{
    public static void main( String[] args )
    {
        CalculatorResult result = Calculator.add(5, 5);
        System.out.println("5 + 5 = " + result.getResult());

    }
}
