package org.swe3643.calculatorengine;

import static org.junit.jupiter.api.Assertions.*;

class ConstantsTest {

    //add tests
    @org.junit.jupiter.api.Test
    void Constants_EPSILON_Matches() {
        //arrange
        double expected = 0.00000001d;

        //act
        double result = Constants.EPSILON;

        //assert
        assertEquals(expected, result);
    }

    @org.junit.jupiter.api.Test
    void Constants_NOT_A_NUMBER_Matches() {
        //arrange
        String expected = "Not a Number";

        //act
        String result = Constants.NOT_A_NUMBER;

        //assert
        assertEquals(expected, result);
    }

}