package org.swe3643.calculatorengine;

import static org.junit.jupiter.api.Assertions.*;

class CalculatorTests {

    private static final double EPSILON = 0.00000001d;

    @org.junit.jupiter.api.Test
    void Calculator_twoValues_returnSum() {
        //arrange
        double inputA = 2.2501d;
        double inputB = -3.99345d;
        double expected = -1.74335d;

        //act
        CalculatorResult result = Calculator.add(inputA, inputB);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void Calculator_twoValues_returnsDifference() {
        //arrange
        double inputA = 2.2501d;
        double inputB = -3.99345d;
        double expected = 6.24355d;

        //act
        CalculatorResult result = Calculator.subtract(inputA, inputB);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void Calculator_twoValues_returnsProduct() {
        //arrange
        double inputA = 2.2501d;
        double inputB = -3.99345d;
        double expected = -8.98566185d;

        //act
        CalculatorResult result = Calculator.multiply(inputA, inputB);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void Calculator_numeratorAndNonZeroDenominator_returnsDivision() {
        //arrange
        double inputA = 2.2501d;
        double inputB = -3.99345d;
        double expected = -0.56344765;

        //act
        CalculatorResult result = Calculator.divide(inputA, inputB);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void Calculator_numeratorAndNonZeroDenominator_returnsNotANumber() {
        //arrange
        double inputA = 2.2501d;
        double inputB = 0d;
        double expected = Double.NaN;
        final String errorMsg = Constants.NOT_A_NUMBER;

        //act
        CalculatorResult result = Calculator.divide(inputA, inputB);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertEquals(errorMsg, result.getErrorMessage());
        assertFalse(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void CalculatorResult_twoValuesDifferentByMoreThan8Places_returnsEquals() {
        //arrange
        double inputA = 2.2501d;
        double inputB = 2.250100001d;
        double expected = 1d;

        //act
        CalculatorResult result = Calculator.equals(inputA, inputB);
        System.out.println("Difference: " + result.getAdditionalData()[0]);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void CalculatorResult_twoValuesDifferentBy8Places_returnsEquals() {
        //arrange
        double inputA = 2.2501d;
        double inputB = 2.25010001d;
        double expected = 1d;

        //act
        CalculatorResult result = Calculator.equals(inputA, inputB);
        System.out.println("Difference: " + result.getAdditionalData()[0]);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void CalculatorResult_twoValuesDifferentByLessThan8Places_returnsNotEquals() {
        //arrange
        double inputA = 2.2501d;
        double inputB = 2.25010002d;
        double expected = 0d;

        //act
        CalculatorResult result = Calculator.equals(inputA, inputB);
        System.out.println("Difference: " + result.getAdditionalData()[0]);

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertTrue(result.isSuccess());
    }

    @org.junit.jupiter.api.Test
    void CalculatorResultFailed_constantErrorValues_returnsFailureResult() {
        //arrange
        String errorMessage = Constants.NOT_A_NUMBER;
        double expected = Double.NaN;

        //act
        CalculatorResult result = new CalculatorResultFailed("Operation");

        //assert
        assertEquals(expected, result.getResult(), EPSILON);
        assertFalse(result.isSuccess());
        assertEquals(errorMessage, result.getErrorMessage());
    }
}