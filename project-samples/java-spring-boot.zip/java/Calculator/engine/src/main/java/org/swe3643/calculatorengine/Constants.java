package org.swe3643.calculatorengine;

final class Constants {
    static final String NOT_A_NUMBER = "Not a Number";

    static final double EPSILON = 0.00000001d;
}
