package org.swe3643.calculatorengine;

public class Calculator {
    public static CalculatorResult add(double inputA, double inputB) {
        double sum = inputA + inputB;
        return new CalculatorResult(sum, inputA + " + " + inputB + " =");
    }

    public static CalculatorResult subtract(double inputA, double inputB) {
        double difference = inputA - inputB;
        return new CalculatorResult(difference, inputA + " - " + inputB + " =");
    }

    public static CalculatorResult multiply(double inputA, double inputB) {
        double product = inputA * inputB;
        return new CalculatorResult(product, inputA + " * " + inputB + " =");
    }

    public static CalculatorResult divide(double inputA, double inputB) {
        String operation = inputA + " / " + inputB + " =";
        if (isZero(inputB)) {
            return new CalculatorResultFailed(operation);

        }

        double quotient = inputA / inputB;
        return new CalculatorResult(quotient, operation);
    }

    private static boolean isZero(double input) {
        return input < Constants.EPSILON && input > -Constants.EPSILON;
    }

    public static CalculatorResult equals(double inputA, double inputB) {
        String operation = inputA + " == " + inputB + " =";
        CalculatorResult result;
        double difference = Math.abs(inputA - inputB);
        boolean equals = difference < Constants.EPSILON;
        result = equals
                ? new CalculatorResult(1d, operation)
                : new CalculatorResult(0d, operation);
        result.setAdditionalData(new Object[] {difference});
        return result;
    }
}
