package org.swe3643.calculatorengine;

public class CalculatorResultFailed extends CalculatorResult {

    CalculatorResultFailed(String operation) {

        super(Double.NaN, operation);
        this.success = false;
        this.errorMessage = Constants.NOT_A_NUMBER;
    }
}