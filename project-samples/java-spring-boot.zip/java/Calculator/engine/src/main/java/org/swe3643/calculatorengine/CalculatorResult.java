
package org.swe3643.calculatorengine;

public class CalculatorResult {
    private double result = Double.NaN;

    private String operation = "";

    //array of additional data objects
    private Object[] additionalData = new Object[0];

    protected boolean success = true;

    protected String errorMessage = "";

    CalculatorResult(double result, String operation) {

        this.result = result;
        this.operation = operation;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public double getResult() {
        return result;
    }

    public Object[] getAdditionalData() {
        return additionalData;
    }

    public void setAdditionalData(Object[] additionalData) {
        this.additionalData = additionalData;
    }

    // Overriding toString method
    @Override
    public String toString() {

        String moreData = (additionalData.length > 0
                ? ", Additional Data: " + java.util.Arrays.toString(additionalData)
                : "");
        return (success
                ? "Success: "
                : "Failed: ") + result +
                (success
                        ? ""
                        : ", " + errorMessage)
                + moreData;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }
}